public class WrongArgumentException extends Exception {
    public WrongArgumentException(String message) {
        // Here, you will call Exception's constructor with message argument.
        super(message);
    }
}
